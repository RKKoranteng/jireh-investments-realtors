<!-- index styles -->

<style>.u-section-1 {background-image: none}
.u-section-1 .u-sheet-1 {min-height: 410px}
.u-section-1 .u-layout-wrap-1 {width: 843px; margin: 50px auto 0 149px}
.u-section-1 .u-image-1 {min-height: 310px; background-position: 50% 50%}
.u-section-1 .u-container-layout-1 {padding: 20px}
.u-section-1 .u-layout-cell-2 {min-height: 310px}
.u-section-1 .u-container-layout-2 {padding: 20px 15px}
.u-section-1 .u-text-1 {margin: 0 30px 0 0}
.u-section-1 .u-metadata-1 {margin: 13px auto 0 0}
.u-section-1 .u-text-2 {margin: 23px 30px 0 0}
.u-section-1 .u-link-1 {margin: 30px auto 0 0} 
@media (max-width: 1199px){ .u-section-1 .u-sheet-1 {min-height: 368px}
.u-section-1 .u-layout-wrap-1 {width: 695px; margin-bottom: 50px; margin-left: 123px}
.u-section-1 .u-image-1 {min-height: 318px}
.u-section-1 .u-layout-cell-2 {min-height: 318px}
.u-section-1 .u-container-layout-2 {padding-left: 12px}
.u-section-1 .u-text-1 {margin-right: 25px}
.u-section-1 .u-metadata-1 {font-weight: normal}
.u-section-1 .u-text-2 {margin-right: 25px}
.u-section-1 .u-link-1 {font-weight: normal} }
@media (max-width: 991px){ .u-section-1 .u-sheet-1 {min-height: 328px}
.u-section-1 .u-layout-wrap-1 {margin-right: initial; margin-left: initial; width: auto}
.u-section-1 .u-image-1 {min-height: 328px}
.u-section-1 .u-container-layout-1 {padding-left: 30px; padding-right: 30px}
.u-section-1 .u-layout-cell-2 {min-height: 328px}
.u-section-1 .u-container-layout-2 {padding-left: 30px; padding-right: 30px}
.u-section-1 .u-text-1 {margin-right: 19px}
.u-section-1 .u-text-2 {margin-right: 19px} }
@media (max-width: 767px){ .u-section-1 .u-sheet-1 {min-height: 756px}
.u-section-1 .u-container-layout-1 {padding-left: 10px; padding-right: 10px}
.u-section-1 .u-container-layout-2 {padding-left: 10px; padding-right: 10px}
.u-section-1 .u-text-1 {margin-right: 14px}
.u-section-1 .u-text-2 {margin-right: 85px} }
@media (max-width: 575px){ .u-section-1 .u-sheet-1 {min-height: 728px}
.u-section-1 .u-layout-wrap-1 {margin-bottom: 20px; width: auto; margin-right: initial; margin-left: initial}
.u-section-1 .u-image-1 {min-height: 295px}
.u-section-1 .u-layout-cell-2 {min-height: 333px}
.u-section-1 .u-text-1 {margin-right: 9px}
.u-section-1 .u-text-2 {margin-right: 9px} }
.u-section-2 {background-image: none}
.u-section-2 .u-sheet-1 {min-height: 410px}
.u-section-2 .u-layout-wrap-1 {width: 843px; margin: 50px auto 0 149px}
.u-section-2 .u-image-1 {min-height: 310px; background-position: 50% 50%}
.u-section-2 .u-container-layout-1 {padding: 20px}
.u-section-2 .u-layout-cell-2 {min-height: 310px}
.u-section-2 .u-container-layout-2 {padding: 20px 15px}
.u-section-2 .u-text-1 {margin: 0 30px 0 0}
.u-section-2 .u-metadata-1 {margin: 13px auto 0 0}
.u-section-2 .u-text-2 {margin: 23px 30px 0 0}
.u-section-2 .u-link-1 {margin: 30px auto 0 0} 
@media (max-width: 1199px){ .u-section-2 .u-sheet-1 {min-height: 368px}
.u-section-2 .u-layout-wrap-1 {width: 695px; margin-bottom: 50px; margin-left: 123px}
.u-section-2 .u-image-1 {min-height: 318px}
.u-section-2 .u-layout-cell-2 {min-height: 318px}
.u-section-2 .u-container-layout-2 {padding-left: 12px}
.u-section-2 .u-text-1 {margin-right: 25px}
.u-section-2 .u-metadata-1 {font-weight: normal}
.u-section-2 .u-text-2 {margin-right: 25px}
.u-section-2 .u-link-1 {font-weight: normal} }
@media (max-width: 991px){ .u-section-2 .u-sheet-1 {min-height: 328px}
.u-section-2 .u-layout-wrap-1 {margin-right: initial; margin-left: initial; width: auto}
.u-section-2 .u-image-1 {min-height: 328px}
.u-section-2 .u-container-layout-1 {padding-left: 30px; padding-right: 30px}
.u-section-2 .u-layout-cell-2 {min-height: 328px}
.u-section-2 .u-container-layout-2 {padding-left: 30px; padding-right: 30px}
.u-section-2 .u-text-1 {margin-right: 19px}
.u-section-2 .u-text-2 {margin-right: 19px} }
@media (max-width: 767px){ .u-section-2 .u-sheet-1 {min-height: 756px}
.u-section-2 .u-container-layout-1 {padding-left: 10px; padding-right: 10px}
.u-section-2 .u-container-layout-2 {padding-left: 10px; padding-right: 10px}
.u-section-2 .u-text-1 {margin-right: 14px}
.u-section-2 .u-text-2 {margin-right: 85px} }
@media (max-width: 575px){ .u-section-2 .u-sheet-1 {min-height: 728px}
.u-section-2 .u-layout-wrap-1 {margin-bottom: 20px; width: auto; margin-right: initial; margin-left: initial}
.u-section-2 .u-image-1 {min-height: 295px}
.u-section-2 .u-layout-cell-2 {min-height: 333px}
.u-section-2 .u-text-1 {margin-right: 9px}
.u-section-2 .u-text-2 {margin-right: 9px} }
.u-section-3 {background-image: none}
.u-section-3 .u-sheet-1 {min-height: 410px}
.u-section-3 .u-layout-wrap-1 {width: 843px; margin: 50px auto 0 149px}
.u-section-3 .u-image-1 {min-height: 310px; background-position: 50% 50%}
.u-section-3 .u-container-layout-1 {padding: 20px}
.u-section-3 .u-layout-cell-2 {min-height: 310px}
.u-section-3 .u-container-layout-2 {padding: 20px 15px}
.u-section-3 .u-text-1 {margin: 0 30px 0 0}
.u-section-3 .u-metadata-1 {margin: 13px auto 0 0}
.u-section-3 .u-text-2 {margin: 23px 30px 0 0}
.u-section-3 .u-link-1 {margin: 30px auto 0 0} 
@media (max-width: 1199px){ .u-section-3 .u-sheet-1 {min-height: 368px}
.u-section-3 .u-layout-wrap-1 {width: 695px; margin-bottom: 50px; margin-left: 123px}
.u-section-3 .u-image-1 {min-height: 318px}
.u-section-3 .u-layout-cell-2 {min-height: 318px}
.u-section-3 .u-container-layout-2 {padding-left: 12px}
.u-section-3 .u-text-1 {margin-right: 25px}
.u-section-3 .u-metadata-1 {font-weight: normal}
.u-section-3 .u-text-2 {margin-right: 25px}
.u-section-3 .u-link-1 {font-weight: normal} }
@media (max-width: 991px){ .u-section-3 .u-sheet-1 {min-height: 328px}
.u-section-3 .u-layout-wrap-1 {margin-right: initial; margin-left: initial; width: auto}
.u-section-3 .u-image-1 {min-height: 328px}
.u-section-3 .u-container-layout-1 {padding-left: 30px; padding-right: 30px}
.u-section-3 .u-layout-cell-2 {min-height: 328px}
.u-section-3 .u-container-layout-2 {padding-left: 30px; padding-right: 30px}
.u-section-3 .u-text-1 {margin-right: 19px}
.u-section-3 .u-text-2 {margin-right: 19px} }
@media (max-width: 767px){ .u-section-3 .u-sheet-1 {min-height: 756px}
.u-section-3 .u-container-layout-1 {padding-left: 10px; padding-right: 10px}
.u-section-3 .u-container-layout-2 {padding-left: 10px; padding-right: 10px}
.u-section-3 .u-text-1 {margin-right: 14px}
.u-section-3 .u-text-2 {margin-right: 85px} }
@media (max-width: 575px){ .u-section-3 .u-sheet-1 {min-height: 728px}
.u-section-3 .u-layout-wrap-1 {margin-bottom: 20px; width: auto; margin-right: initial; margin-left: initial}
.u-section-3 .u-image-1 {min-height: 295px}
.u-section-3 .u-layout-cell-2 {min-height: 333px}
.u-section-3 .u-text-1 {margin-right: 9px}
.u-section-3 .u-text-2 {margin-right: 9px} }
.u-section-4 {background-image: none}
.u-section-4 .u-sheet-1 {min-height: 410px}
.u-section-4 .u-layout-wrap-1 {width: 843px; margin: 50px auto 0 149px}
.u-section-4 .u-image-1 {min-height: 310px; background-position: 50% 50%}
.u-section-4 .u-container-layout-1 {padding: 20px}
.u-section-4 .u-layout-cell-2 {min-height: 310px}
.u-section-4 .u-container-layout-2 {padding: 20px 15px}
.u-section-4 .u-text-1 {margin: 17px 30px 0 0}
.u-section-4 .u-metadata-1 {margin: 13px auto 0 0}
.u-section-4 .u-text-2 {margin: 23px 30px 0 0}
.u-section-4 .u-link-1 {margin: 30px auto 0 0} 
@media (max-width: 1199px){ .u-section-4 .u-sheet-1 {min-height: 368px}
.u-section-4 .u-layout-wrap-1 {width: 695px; margin-bottom: 50px; margin-left: 123px}
.u-section-4 .u-image-1 {min-height: 318px}
.u-section-4 .u-layout-cell-2 {min-height: 318px}
.u-section-4 .u-container-layout-2 {padding-left: 12px}
.u-section-4 .u-text-1 {margin-right: 25px}
.u-section-4 .u-metadata-1 {font-weight: normal}
.u-section-4 .u-text-2 {margin-right: 25px}
.u-section-4 .u-link-1 {font-weight: normal} }
@media (max-width: 991px){ .u-section-4 .u-sheet-1 {min-height: 328px}
.u-section-4 .u-layout-wrap-1 {margin-right: initial; margin-left: initial; width: auto}
.u-section-4 .u-image-1 {min-height: 328px}
.u-section-4 .u-container-layout-1 {padding-left: 30px; padding-right: 30px}
.u-section-4 .u-layout-cell-2 {min-height: 328px}
.u-section-4 .u-container-layout-2 {padding-left: 30px; padding-right: 30px}
.u-section-4 .u-text-1 {margin-right: 19px}
.u-section-4 .u-text-2 {margin-right: 19px} }
@media (max-width: 767px){ .u-section-4 .u-sheet-1 {min-height: 756px}
.u-section-4 .u-container-layout-1 {padding-left: 10px; padding-right: 10px}
.u-section-4 .u-container-layout-2 {padding-left: 10px; padding-right: 10px}
.u-section-4 .u-text-1 {margin-right: 14px}
.u-section-4 .u-text-2 {margin-right: 85px} }
@media (max-width: 575px){ .u-section-4 .u-sheet-1 {min-height: 728px}
.u-section-4 .u-layout-wrap-1 {margin-bottom: 20px; width: auto; margin-right: initial; margin-left: initial}
.u-section-4 .u-image-1 {min-height: 295px}
.u-section-4 .u-layout-cell-2 {min-height: 333px}
.u-section-4 .u-text-1 {margin-right: 9px}
.u-section-4 .u-text-2 {margin-right: 9px} }
.u-section-5 .u-sheet-1 {min-height: 107px}
.u-section-5 .u-pagination-1 {margin: 25px auto} 
@media (max-width: 1199px){ .u-section-5 .u-pagination-1 {margin-bottom: 0} }
@media (max-width: 575px){ .u-section-5 .u-sheet-1 {min-height: 164px} }
</style>
