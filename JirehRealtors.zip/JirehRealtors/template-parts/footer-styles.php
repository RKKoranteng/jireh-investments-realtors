<!-- footer styles -->

<style>.u-footer .u-sheet-1 {min-height: 324px}
.u-footer .u-image-1 {margin: 60px auto 0}
.u-footer .u-logo-image-1 {max-width: 72px; max-height: 72px}
.u-footer .u-social-icons-1 {height: 23px; min-height: 16px; width: 56px; min-width: 42px; white-space: nowrap; animation-duration: 1000ms; margin: 30px auto 0}
.u-footer .u-icon-1 {height: 100%}
.u-footer .u-icon-2 {height: 100%}
.u-footer .u-line-1 {transform-origin: left center 0; width: 1140px; margin: 30px auto 0 0}
.u-footer .u-text-1 {width: 530px; margin: 30px auto 10px}
.u-footer .u-btn-1 {padding: 0}
.u-footer .u-btn-2 {padding: 0}
.u-footer .u-btn-3 {padding: 0} 
@media (max-width: 1199px){ .u-footer .u-image-1 {width: 66px; height: 63px}
.u-footer .u-social-icons-1 {margin-left: 420px}
.u-footer .u-line-1 {margin-right: initial; margin-left: initial; width: auto}
.u-footer .u-text-1 {width: 437px} }
@media (max-width: 991px){ .u-footer .u-image-1 {width: 51px}
.u-footer .u-social-icons-1 {margin-left: auto}
.u-footer .u-text-1 {width: 335px} }
@media (max-width: 767px){ .u-footer .u-image-1 {width: 47px}
.u-footer .u-text-1 {width: 314px} }
@media (max-width: 575px){ .u-footer .u-image-1 {width: 40px}
.u-footer .u-text-1 {width: 263px} }</style>
