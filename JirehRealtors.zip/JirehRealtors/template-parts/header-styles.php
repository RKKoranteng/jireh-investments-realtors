<!-- header styles -->

<link id="u-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
<style>.u-header {background-image: none}
.u-header .u-sheet-1 {min-height: 86px}
.u-header .u-image-1 {animation-duration: 1000ms; margin: 7px auto 0 0}
.u-header .u-logo-image-1 {max-width: 391px; max-height: 391px}
.u-header .u-menu-1 {margin: -48px 0 31px auto}
.u-header .u-nav-1 {font-size: 1rem; letter-spacing: 0; font-weight: 400}
.u-block-b005-28 {font-size: 1rem; letter-spacing: 0}
.u-header .u-nav-2 {font-size: 1rem; letter-spacing: 0}
.u-block-b005-29 {font-size: 1rem; letter-spacing: 0} 
@media (max-width: 1199px){ .u-header .u-image-1 {width: 64px; height: 32px}
.u-header .u-menu-1 {width: auto; margin-top: -48px; margin-right: 0} }
@media (max-width: 767px){ .u-header .u-image-1 {width: auto} }</style>
