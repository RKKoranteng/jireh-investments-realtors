<!-- post styles -->

<style>.u-section-1 {background-image: none}
.u-section-1 .u-sheet-1 {min-height: 785px}
.u-section-1 .u-text-1 {margin: 60px 0 0}
.u-section-1 .u-gallery-1 {width: 1140px; height: 589px; grid-gap: 10px 10px; margin: 20px auto 0 0}
.u-section-1 .u-carousel-indicators-1 {position: absolute; bottom: 10px}
.u-section-1 .u-over-slide-1 {min-height: 100px; padding: 10px}
.u-section-1 .u-over-slide-2 {min-height: 100px; padding: 10px}
.u-section-1 .u-carousel-control-1 {position: absolute; left: 10px; width: 40px; height: 40px}
.u-section-1 .u-carousel-control-2 {position: absolute; right: 10px; width: 40px; height: 40px}
.u-section-1 .u-metadata-1 {margin: 3px 808px 0 0}
.u-section-1 .u-text-2 {margin: 30px 0 0}
.u-section-1 .u-btn-1 {border-style: none; letter-spacing: 1px; background-image: none; margin: 30px 0 60px} 
@media (max-width: 1199px){ .u-section-1 .u-text-1 {margin-right: initial; margin-left: initial}
.u-section-1 .u-gallery-1 {width: 940px}
.u-section-1 .u-metadata-1 {margin-right: 608px}
.u-section-1 .u-btn-1 {font-weight: normal; text-transform: none} }
@media (max-width: 991px){ .u-section-1 .u-sheet-1 {min-height: 768px}
.u-section-1 .u-gallery-1 {width: 720px}
.u-section-1 .u-metadata-1 {margin-top: 493px; margin-right: 388px} }
@media (max-width: 767px){ .u-section-1 .u-gallery-1 {width: 540px}
.u-section-1 .u-metadata-1 {margin-right: 208px}
.u-section-1 .u-text-2 {margin-right: initial; margin-left: initial} }
@media (max-width: 575px){ .u-section-1 .u-sheet-1 {min-height: 659px}
.u-section-1 .u-gallery-1 {width: 340px}
.u-section-1 .u-metadata-1 {margin-top: 359px; margin-right: 8px} }
</style>
